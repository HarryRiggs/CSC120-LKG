﻿namespace LogicCircuit.Abstractions.Infrastructure
{
    public interface IOutputPin
    {
        bool State { get; }
    }
}