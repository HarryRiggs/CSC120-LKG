﻿namespace LogicCircuit.Test
{
    public class TruthValue2
    {
        public bool A {get; set; }
        public bool B { get; set; }
        public bool C { get; set; }
    }
}
